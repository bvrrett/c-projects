/**
 * CS 105 Theory and Practice I
 * CRN: 39626
 * Assignment: ResistorDecoder
 *
 * Statement of code ownership: I hereby state that I have written all of this
 * code and I have not copied this code from any other person or source.
 *
 * @author Spencer Barrett
 */
package edu.sbcc.cs105;

import java.lang.reflect.Array;


public class ResistorDecoder {
	public String band1;
	public String band2;
	public String multiplier;
	public String tolerance;
	public String b;
	public double firstBand;
	public double secBand;
	private String g;
	private String decodedResistor;
	public ResistorDecoder() {

	}
	public void printTest() {
		System.out.print(this.decodedResistor);
	}
	public String decodeResistor(String[] resistorColor) {
		int tmp;
		int temp;
		int comb;
		String twelve;
		this.band1 = (String)Array.get(resistorColor, 0);
		this.band2 = (String)Array.get(resistorColor, 1);
		this.multiplier = (String)Array.get(resistorColor, 2);
		this.tolerance = (String)Array.get(resistorColor, 3);
		ToleranceLookup t = new ToleranceLookup();
		NumberLookup z = new NumberLookup();
		MultiplierLookup multiple = new MultiplierLookup();
		t.get(this.tolerance);
		this.b = t.get(this.tolerance);     //delete
		this.firstBand = z.getDouble(this.band1); //delete
		this.secBand = z.getDouble(this.band2); //delete
		this.g = multiple.get(this.multiplier);	//delete
		tmp = Integer.parseInt(this.g);
		int p = (int)firstBand;
		int q = (int)secBand;
		if (p > 0) {
			if(tmp >= 0) {
				this.band1 = z.get(band1);
				this.band2 = z.get(band2);
				twelve = this.band1 + this.band2;
				comb = Integer.parseInt(twelve);
				comb = comb * 10;
				temp = (int)Math.pow(comb, tmp);
				this.decodedResistor = (temp + "");
			}
		
		}else {
			
			temp = (int)Math.pow(p, tmp);
			this.decodedResistor = (temp + "");
		}
		return this.decodedResistor;
	}
	

}
