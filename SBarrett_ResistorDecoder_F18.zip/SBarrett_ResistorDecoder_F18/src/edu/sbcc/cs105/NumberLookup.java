package edu.sbcc.cs105;

import java.lang.reflect.Array;

public class NumberLookup extends LookupTable{
	private String color;
	private double numberValue;
	private String numVal;
	public double getDouble(String color) {
		this.color = color;
		String[] bandColor = {"Black", "Brown", "Red", "Orange", "Yellow", "Green", "Blue", " Voilet", "Gray", "White"};
		double[] number = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
		int i;
		for (i = 0; i < Array.getLength(bandColor); i++) {
			if (this.color.equals(Array.get(bandColor, i))) {
				this.numberValue = (double)Array.get(number, i);
			}
		}
		return this.numberValue;
		
	}

	public String get(String color) {
		this.color = color;
		String[] bandColor = {"Black", "Brown", "Red", "Orange", "Yellow", "Green", "Blue", " Voilet", "Gray", "White"};
		String[] number = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};
		int i;
		for (i = 0; i < Array.getLength(bandColor); i++) {
			if (this.color.equals(Array.get(bandColor, i))) {
				this.numVal = (String)Array.get(number, i);
			}
		}
		return this.numVal;
		
	}

}
