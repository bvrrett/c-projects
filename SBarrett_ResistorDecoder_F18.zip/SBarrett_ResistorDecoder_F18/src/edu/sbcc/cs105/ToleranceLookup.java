package edu.sbcc.cs105;

import java.lang.reflect.Array;

public class ToleranceLookup extends LookupTable{
	private String color;
	private String toleranceValue;
	public String get(String color) {
		this.color = color;
		String[] toleranceColor = {"Brown", "Red", "Yellow", "Green", "Blue", " Violet", "Gray", "Gold", "Silver"};
		String[] tolerance = {"�1%", "�2%", "�5%", "�0.5%", "�0.25%", "�0.1%", "�10%", "�5%", "�10%"};
		int i;
		for (i = 0; i < Array.getLength(toleranceColor) - 1; i++) {
			if (this.color.equals(Array.get(toleranceColor, i))) {
				this.toleranceValue = (String)Array.get(tolerance, i);
			}
		}
		return this.toleranceValue;
	}

}
