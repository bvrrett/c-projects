package edu.sbcc.cs105;

import java.lang.reflect.Array;

public class MultiplierLookup extends LookupTable{
	private String multiplierValue;
	private String color;
	public String get(String color) {
		int tmp;
		this.color = color;
		String[] multiplierColor = {"Black", "Brown", "Red", "Orange", "Yellow", "Green", "Blue", "Violet", "Gray", "White", "Gold", "Silver"};
		int[] multiplier = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, -1, -2};
		int i;
		for (i = 0; i < Array.getLength(multiplierColor); i++) {
			if(this.color.equals(Array.get(multiplierColor, i))) {
				tmp = (int)Array.get(multiplier, i);
				this.multiplierValue = new Integer(tmp).toString();
			}
		}
		return this.multiplierValue;
	}
}
