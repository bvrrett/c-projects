package edu.sbcc.cs105;

public abstract class LookupTable {	

	
	public abstract String get(String color);

}
