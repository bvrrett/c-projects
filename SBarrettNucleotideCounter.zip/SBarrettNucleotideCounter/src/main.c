/*
 ============================================================================
 Name        : SBarrettNucleotideCounter.c
 Author      : Spencer Barrett
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int main(void) {
	FILE *fp; // initialize file pointers
	FILE *fp1;
	int c;// initialize variables for nucleotide cases
	int a;
	int t;
	int g;
	int f;// variable for switch case statements
	setvbuf(stdout, NULL, _IONBF, 0);
	char input[BUFSIZ];// character array for input & output
	char output[BUFSIZ];
	printf("Please enter the input file name: \n");
	scanf("%s", &input);
	printf("Please enter the output file name: \n");
	scanf("%s", &output);
	fp = fopen(input, "r");// open fp for reading
	fp1 = fopen(output, "w");// open fp1 for writing
	while ((f = fgetc(fp)) != EOF) {// loop through fp until it reaches end of file

		switch (f) {
		case 'A':
			a++;// increment if case is reached...
			break;
		case 'C':
			c++;
			break;
		case 'G':
			g++;
			break;
		case 'T':
			t++;
			break;
		case '\n':// if newline is reached print out results of count and reset for another new line
			fprintf(fp1, "%d %d %d %d\n", a, c, g, t);
			a = 0, c = 0, g = 0, t = 0;

			break;
		default: // if none of the cases are satisfied print Error
			printf("Error");
		}

	}
	fclose(fp); // close fp1 & fp
	fclose(fp1);
	printf("Complete\n");
	return EXIT_SUCCESS;
}
