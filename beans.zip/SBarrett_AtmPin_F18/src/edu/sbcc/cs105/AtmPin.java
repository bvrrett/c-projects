/**
 * CS 105 Theory and Practice I
 * CRN: 39626
 * Assignment: AtmPin
 *
 * Statement of code ownership: I hereby state that I have written all of this
 * code and I have not copied this code from any other person or source.
 *
 * @author Spencer Barrett
 */
package edu.sbcc.cs105;

public class AtmPin {
	private String code;
	private boolean badPassword;
	private int counter = 0;
	private boolean blocked = false;
	public AtmPin() {
		
	}
	
	public boolean acceptPinCode(String code) {
		this.code = code;
		if (blocked == false) {
			if (code == "1234") {
				badPassword = false;
				return true;
			} else  {
				counter++;
				badPassword = true;
				isBadPassword();
				return false;
			} 
		}else {
			badPassword = true;
			isBadPassword();
			blocked = true;
			isBlocked();
			
			return false;
		}
	}
	
	public boolean isBadPassword() {
			if (badPassword == true) {
				if(counter >= 3) {
					blocked = true;
				}
				return true;
			}else {
				return false;
			}
		}
	
	
	public boolean isBlocked() {
		if (blocked == true) {
			return true;
			
		}else {
			return false;
		}
	}
	
	public void resetPasswordAttempts() {
		blocked = false;
		counter = 0;
		
	}

}
