/**
 * CS 105 Theory and Practice I
 * CRN: 39626
 * Assignment: AtmPin
 *
 * Statement of code ownership: I hereby state that I have written all of this
 * code and I have not copied this code from any other person or source.
 *
 * @author Spencer Barrett
 */
package edu.sbcc.cs105;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String b = "1233";
		String c = "1222";
		String d = "1111";
		String e = "1234";
		AtmPin tst = new AtmPin();
		tst.acceptPinCode(b);
		System.out.println(tst.isBadPassword());
		tst.acceptPinCode(c);
		System.out.println(tst.isBadPassword());
		System.out.println(tst.isBlocked());
		tst.acceptPinCode(d);
		System.out.println(tst.isBadPassword());
		System.out.println(tst.isBlocked());
		tst.acceptPinCode(e);
		System.out.println(tst.isBadPassword());
		System.out.println(tst.isBlocked());

		
	
	}

}
