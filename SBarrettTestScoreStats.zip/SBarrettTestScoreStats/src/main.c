/*
 ============================================================================
 Name        : spencer barrett
 Author      :
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>

int main(void) {
	setvbuf(stdout, NULL, _IONBF, 0);
	float min = INT_MAX;
	float max = INT_MIN; // max and min initializing against limit values
	float standardDev;
	float average = 0;
	float sum = 0;
	float sumSquares = 0;
	int counter = 0;
	char input[BUFSIZ];
	float scores;
	printf(
			"Please enter scores, one per line, and press <Enter> when done: \n");
	do { //grabs the input from the char* array and runs in a loop testing min. and max. values and adding scores
		fgets(input, BUFSIZ, stdin);
		scores = atof(input);
		if (scores != 0 && min > scores) {
			min = scores;
		}
		if (max < scores) {
			max = scores;
		}
		sum += scores;
		sumSquares += pow(scores, 2);
		counter++;
	} while (input[0] != '\n'); //sets the condition for the loop

	counter = (counter - 1);
	if (counter == 0) {
		average = 0;
		standardDev = 0;
		min = 0;
		printf("%d\t %f\t %f\t %f\t %f\t \n", (counter), min, max, average,
				standardDev);

	} else {
		average = sum / (counter);
		standardDev = sqrt(
				((sumSquares) - ((pow(sum, 2)) / (counter))) / (counter));
		printf("%d\t %f\t %f\t %f\t %f\t \n", (counter), min, max, average,
				standardDev); //runs the scores through an algorithm to get standard deviation
	}
	return EXIT_SUCCESS;
}

